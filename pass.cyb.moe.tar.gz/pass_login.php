<?php
$qq=$_POST['qq'];
$pd=$_POST['pd'];
$token=md5($pd.mt_rand(1,58345).mt_rand(123,126).$qq);
setcookie("user", $token, time()+3600);

if($pd == NULL || $qq== NULL){
  echo '为啥不输入呢？';
}
try {
		$con = new PDO('mysql:host=localhost;dbname=pass', 'pass', 'DraN2DS3xkTHnpbi');
	} catch (PDOException $e) {
		echo "Error: Can not connect to sever.";
		exit();
	}
	$res = $con -> query("SELECT * FROM `Members_Basic_Info` WHERE `Members_QQ` = '$qq'");
	$row = $res -> fetch();
if(md5($pd)==$row['Members_Pass']){
  $con ->query("UPDATE `Members_Basic_Info` SET `Members_Token` = '$token' WHERE `Members_Basic_Info`.`Members_QQ` = $qq;");
  echo $_COOKIE["user"];
}else{
  echo '1';
}

?>