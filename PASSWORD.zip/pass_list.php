<?php
header("Content-type: text/html; charset=UTF-8");
//error_reporting(E_ALL ^ E_NOTICE);
try {
		$con = new PDO('mysql:host=localhost;dbname=数据库名称', '数据库账号', '数据库密码');
	} catch (PDOException $e) {
		echo "Error: Can not connect to sever.";
		exit();
	}
	$token=$_COOKIE["user"];
	$res = $con -> query("SELECT * FROM `Members_Basic_Info` WHERE `Members_Token` = '$token'");
	$row = $res -> fetch();
		//print_r($row);

	if(empty($row)==true){
		setcookie("user", "", time()-6000);
		echo 'window.location="index.html";';
		exit();
	}
		$qq=$row['Members_QQ'];
	$res = $con -> query("SELECT * FROM `$qq`");
	  while($row=$res->fetch()){
        $bh=$row['Game_ID'];
        $yxmz=$row['Game_Name'];
        $dq=$row['Game_Area'];
        $nc=$row['Game_PName'];
        $zh=$row['Game_Acc'];
        $pass=$row['Game_Pass'];
        $data=$data.'<li><a class="uk-accordion-title" href="#"><span class="uk-badge">'.$bh.'</span><span class="uk-badge">'.$yxmz.'</span><span class="uk-badge">'.$dq.'</span><span class="uk-badge">'.$nc.'</span></a><div class="uk-accordion-content"><div class="uk-margin"><div class="uk-inline uk-width-1-1"><span class="uk-form-icon" uk-icon="icon: user"></span><input id="zh_'.$bh.'" class="uk-input" type="text" value="'.$zh.'"></div></div><div class="uk-margin"><div class="uk-inline uk-width-1-1"><span class="uk-form-icon" uk-icon="icon: lock"></span><input id="pd_'.$bh.'" class="uk-input" type="text" value="'.$pass.'"></div></div><div class="uk-clearfix"><div class="uk-float-right"><button class="uk-button uk-button-default uk-button-small" onclick="set('.$bh.');">修改</button></div><div class="uk-float-left"><button class="uk-button uk-button-default uk-button-small" onclick="del('.$bh.');">删除</button></div></div></div></li>';
    }
    $q='<ul class="uk-align-center" uk-accordion="multiple: true"">';
    $h='</ul>';
	echo "document.write('$q$data$h');document.getElementById('qqnum').innerHTML = '$qq';document.getElementById('qqtx').src='https://q1.qlogo.cn/g?b=qq&nk=$qq&s=100';";
?>