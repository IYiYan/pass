<?php
header("Content-type: text/html; charset=UTF-8");
//error_reporting(E_ALL ^ E_NOTICE);
try {
		$con = new PDO('mysql:host=localhost;dbname=数据库名称', '数据库账号', '数据库密码');
	} catch (PDOException $e) {
		echo "Error: Can not connect to sever.";
		exit();
	}
	$token=$_COOKIE["user"];
	$res = $con -> query("SELECT * FROM `Members_Basic_Info` WHERE `Members_Token` = '$token'");
	$row = $res -> fetch();
		//print_r($row);
	$qq=$row['Members_QQ'];
	$zh=$_POST['zh'];
	$pd=$_POST['pd'];
	$bh=$_POST['bh'];
	$con -> query("UPDATE `$qq` SET `Game_Acc` = '$zh' WHERE `Game_ID` = $bh;");
	$con -> query("UPDATE `$qq` SET `Game_Pass` = '$pd' WHERE `Game_ID` = $bh;");
	
?>